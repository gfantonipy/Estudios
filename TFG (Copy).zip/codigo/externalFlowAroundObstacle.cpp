/*
 * This file is part of the U-Virtual Wind Tunnel.
 *
 * Copyright (C) 2017
 * 
 * The U-Virtual Wind Tunnel is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * The U-Virtual Wind Tunnel is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

//Incluidas cabeceras de Palabos
#include "palabos3D.h"
#include "palabos3D.hh"

#include <sys/types.h> //Cabecera para fork
#include <sys/wait.h> // Cabecera para wait
#include <unistd.h> // Cabecera para execl

//Añadidos namespace que necesitamos
using namespace plb;
using namespace std;

/*
Plantilla creada para transformar 
TODO: ver si se puede con la misma funcion pero en std http://stackoverflow.com/questions/5590381/easiest-way-to-convert-int-to-string-in-c
http://en.cppreference.com/w/cpp/string/basic_string/to_string
*/
namespace util    // Namespace utilizado para almacenar clases y funcione utiles para ciertas tareas.
{
    template < typename TT > std::string to_string( const TT& n )    // Funcion para convertir a un string una variable de tipo arbitraria TT.
    {
        std::ostringstream stm ;   // 1º -> Creamos un objeto de clase ostringstream, un objeto de clase "string buffer" muy util para operaciones de salida con strings.
        stm << n ;    // 2º -> mediante el operador << le asignamos el valor de la variable que queremos pasar, este operador ya se encuentra sobrecargado para los diferetes tipos de datos posibles, de ahi su gran utilidad para poder ser utilizado con diversos tipos de datos.
        return stm.str() ;    // 3º -> Mediante el método str() recuperamos el valor de la variable pasada como un string.
    }
}



typedef double T; //T indica el tipo de dato utilizado para almacenar decimales. Si no hay problemas de memoria se utiliza double, si los hubiera, utilizar float.
typedef Array<T,3> Velocity; //Tipo de dato utilizado para almacenar velocidades. Un array de 3 dimensiones que almacena valores decimales.
#define DESCRIPTOR descriptors::D3Q19Descriptor    // Tipo de mallado a utilizar.
typedef DenseParticleField3D<T,DESCRIPTOR> ParticleFieldT;    //Tipo de campo de particulas virtuales a utilizar.

#define PADDING 8    // Número de digitos a mostrar en el nombre del fichero VTK.

static std::string outputDir("./tmp/"); //Directorio donde volcar los resultados


// Estructura que contiene todos los parametros del tunel y
// y deriva los necesarios para su utilización.
struct Param
{
    T nu;                               // Velocidad cinemática
    T lx, ly, lz;                       // Tamaño del espacio fluido, en unidades fisicas
    T cx, cy, cz;                       // Posicion del centro del obstaculo, en unidades fisicas
    plint cxLB, cyLB, czLB;             // Posicion del centro del obstaculo, en unidades lattice
    bool freeSlipWall;                  // Usar condiciones free-slip en el obstaculo
    bool lateralFreeSlip;               // Usar condicion free-slip en los laterales o condicion de suelo
    T maxT, statT, vtkT;                // Tiempo de duracion de la simulacion, frecuencia con el que se vuelcan los datos de simulacion en pantalla, frecuencia con el que se vuelcan los datos en VTK
    plint resolution;                   // Número de nodos a lo largo de la dirección Y
    T inletVelocity;                    // Velocidad de entrada en el eje X, unidades fisicas
    T uLB;                              // Velocidad de entrada en el eje X, unidades lattice.
    T cSmago;                           // Parametro del modelo Smagorinsky LES.
    plint nx, ny, nz;                   // Resolución de la malla.
    T omega;                            // Parametro de relajacion
    T dx, dt;                           // Incremento discreto del espacio y el tiempo.
    plint maxIter, statIter;            // Número total de iteraciones, y numero de iteraciones entre volcado en pantalla.
    plint vtkIter;                      // Número de iteraciones entre volcado en VTK
    bool useParticles;                  // Usar particulas virtuales o no.
    int particleTimeFactor;             // Factor de tiempo con el cual se calcula el flujo de particulas virtuales.
    T particleProbabilityPerCell;       // Probabilidad de inyeccion de una nueva particula virtual en cada iteración.
    T cutOffSpeedSqr;                   // Criterio de velocidad minima para eliminar particulas
    int maxNumParticlesToWrite;         // Numero maximo de particulas a escribir en VTK

    T outletSpongeZoneWidth;            // Espesor de la Sponge-Zone
    plint numOutletSpongeCells;         // Número de nodos que ocupa la Sponge-Zone
    int outletSpongeZoneType;           // Tipo de Sponge-Zone (Viscosity o Smagorinsky).
    T targetSpongeCSmago;               // En caso de que la Sponge-Zone sea de tipo Smagorinsky, el valor de la contante de Smagorinsky a utilizar.
    plint initialIter;                  // Numero de iteaciones hasta que la velocidad alcanza su valor final.

    Box3D inlet, outlet, lateral1;      // Entrada, Salida y laterales del tunel
    Box3D lateral2, lateral3, lateral4;

    std::string geometry_fname;         // Nombre del fichero STL

    // Parametros propios

    plint iteracionesPrograma;				// Numero de ejecuciones del programa en las que se cambian los angulos entre ellas.
    T Cs;				// Velocidad del sonido en el fluido.
    T densidad;				// Dendisas del fluido.
    T initialIterT;			// Numero de iteraciones durante el cual la velocidad en la entrada del tunel se va acelerando
    bool vtkFile;           // Exportar los datos en VTK o no.
    T phi;                  // Ángulo Phi
    T theta;                  // Ángulo theta
    T psi;                  // Ángulo Psi
    T deltaphi;				// Incremento en phi en cada iteracion
    T deltatheta;				// Incremento en theta en cada iteracion
    T deltapsi;				// Incremento en psi en cada iteracion
    std::string modelo;     // Nombre de la dinamica que se va a utilizar

    Param()                 // Funcion Param llamada sin parametros.
    { }

    Param(std::string xmlFname)    //Funcion Param llamada con el nombre del fichero XML a procesar.
    {
        XMLreader document(xmlFname);    // XMLreader es un objeto que abre y procesa el documento XML. Posteriormente a traves del operador [] es posible acceder a los distintos nodos del fichero y escribirlos en las distintas variables gracias al metodo read.
		// Leemos los nodos del fichero XML que nos interesa y almacenamos la informacion en las variables de la estructura Param.
        document["configuracion"]["geometry"]["filename"].read(geometry_fname);
        document["configuracion"]["geometry"]["center"]["x"].read(cx);
        document["configuracion"]["geometry"]["center"]["y"].read(cy);
        document["configuracion"]["geometry"]["center"]["z"].read(cz);
        document["configuracion"]["geometry"]["freeSlipWall"].read(freeSlipWall);
        document["configuracion"]["geometry"]["lateralFreeSlip"].read(lateralFreeSlip);
        document["configuracion"]["geometry"]["domain"]["x"].read(lx);
        document["configuracion"]["geometry"]["domain"]["y"].read(ly);
        document["configuracion"]["geometry"]["domain"]["z"].read(lz);
        document["configuracion"]["geometry"]["Giros"]["phi"].read(phi);
        document["configuracion"]["geometry"]["Giros"]["theta"].read(theta);
        document["configuracion"]["geometry"]["Giros"]["psi"].read(psi);
        document["configuracion"]["numerics"]["iter"].read(iteracionesPrograma);
        document["configuracion"]["numerics"]["nu"].read(nu);
        document["configuracion"]["numerics"]["ro"].read(densidad);
        document["configuracion"]["numerics"]["inletVelocity"].read(inletVelocity);
        document["configuracion"]["numerics"]["deltaphi"].read(deltaphi);
        document["configuracion"]["numerics"]["deltatheta"].read(deltatheta);
        document["configuracion"]["numerics"]["deltapsi"].read(deltapsi);
        document["configuracion"]["numerics"]["resolution"].read(resolution);
        document["configuracion"]["numerics"]["dt"].read(dt);
        document["configuracion"]["numerics"]["modelo"].read(modelo);
        if (modelo == "Smagorinsky") {
            document["configuracion"]["numerics"]["cSmago"].read(cSmago);    // Solo se lee la variable del modelo de Smagorinsky si utilizamos dicho modelo
        }
        document["configuracion"]["numerics"]["useParticles"].read(useParticles);
        if (useParticles) {     // Solo se leen las variables del modelo de particulas virtuales si utilizamos dicho modelo
            document["configuracion"]["numerics"]["particleTimeFactor"].read(particleTimeFactor);
            document["configuracion"]["numerics"]["particleProbabilityPerCell"].read(particleProbabilityPerCell);
            document["configuracion"]["numerics"]["cutOffSpeedSqr"].read(cutOffSpeedSqr);
            document["configuracion"]["numerics"]["maxNumParticlesToWrite"].read(maxNumParticlesToWrite);
        }
        document["configuracion"]["numerics"]["outletSpongeZoneWidth"].read(outletSpongeZoneWidth);
        std::string zoneType;   //Dinamica usada en la Sponge Zone
        document["configuracion"]["numerics"]["outletSpongeZoneType"].read(zoneType);  // Almacenamos el nombre del tipo de zona utilizada en la Sponge Zone
		
        if ((util::tolower(zoneType)).compare("viscosity") == 0) {
            outletSpongeZoneType = 0;    //Si es de tipo viscoso damos a outletSpongeZoneType un valor de 0
        } else if ((util::tolower(zoneType)).compare("smagorinsky") == 0) {
            outletSpongeZoneType = 1; //Si es de tipo Smagorinsky damos a outletSpongeZoneType un valor de 1
        } else {    // En otro caso mostramos un mensaje de error
            pcout << "The sponge zone type must be either \"Viscosity\" or \"Smagorinsky\"." << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.
            exit(-1);
        }
		
        document["configuracion"]["numerics"]["targetSpongeCSmago"].read(targetSpongeCSmago);
        document["configuracion"]["numerics"]["initialIterT"].read(initialIterT);
        document["configuracion"]["numerics"]["maxT"].read(maxT);
        document["configuracion"]["output"]["statT"].read(statT);
        document["configuracion"]["output"]["vtkFile"].read(vtkFile);
		if (vtkFile){
			document["configuracion"]["output"]["vtkT"].read(vtkT);    // Solo se establece la frecuencia de volcado de ficheros VTK si usamos dicho modelo
		}

        computeLBparameters();    // Llamamos a la funcion que termina de establecer los parametros que faltan por establecer su valor, y se calcula a partir de lso datos que hemos leido anteriormente.
    }

    void computeLBparameters()
    {
    dx = ly / (resolution - 0.0);    // Al ser resolucion de tipo entero, para que la division de un resultado flotante se le resta el valor 0.0. Dividiendo la longitud del tunel en el eje Y por la resolucion que le damos obtenemos el incremento discreto de distancia, utilizado como unidad de distancia Lattice.
	Cs = dx/dt;    // Velocidad del sonido en el fluido.
	uLB = inletVelocity/Cs;    // Adimensionalización de la velocidad del fluido mediante la velocidad del sonido en el fluido.
    T nuLB = nu * dt/(dx*dx);    // Adimensionalizacion de la viscosidad del fluido.
	initialIter = util::roundToInt(initialIterT/dt);    // Número de iteraciones a realizar hasta que qla velocidad de entrada del fluido alcanza el valor establecido. Lo obtenemos adimensionalizando el tiempo que se tarda en alcanzarlo con el incremento temporal discreto de la simulación.
    omega = 1.0/(DESCRIPTOR<T>::invCs2*nuLB+0.5);    // Parámetro de relajación, calculado segun la formula necesaria para nuestro caso.
	
    nx = util::roundToInt(lx/dx) + 1;    // Número de nodos Lattice a lo largo del eje X, redondeo a entero de longitud del tunel en el eje X dividido incremento discreto de distancia más uno.
    ny = util::roundToInt(ly/dx) + 1;    // Número de nodos Lattice a lo largo del eje Y, redondeo a entero de longitud del tunel en el eje Y dividido incremento discreto de distancia más uno.
    nz = util::roundToInt(lz/dx) + 1;    // Número de nodos Lattice a lo largo del eje Z, redondeo a entero de longitud del tunel en el eje Z dividido incremento discreto de distancia más uno.
	
    cxLB = util::roundToInt(cx/dx);    // Posicion del centro del obstaculo en el eje X en unidades Lattice,  redondeo a entero de la posición del centro del obstaculo en el eje X dividido incremento discreto de distancia.
    cyLB = util::roundToInt(cy/dx);    // Posicion del centro del obstaculo en el eje Y en unidades Lattice,  redondeo a entero de la posición del centro del obstaculo en el eje Y dividido incremento discreto de distancia.
    czLB = util::roundToInt(cz/dx);    // Posicion del centro del obstaculo en el eje Z en unidades Lattice,  redondeo a entero de la posición del centro del obstaculo en el eje Z dividido incremento discreto de distancia.
    maxIter   = util::roundToInt(maxT/dt);    // Número total de iteraciones de la simulación. Redondeando a entero el tiempo total de la simulación dividido entre incremento discreto de tiempo.
    statIter  = util::roundToInt(statT/dt);    // Número de iteraciones entre volcado de la fuerza sobre el sólido. Redondeando a entero el tiempo entre volcados dividido entre incremento discreto de tiempo.
    vtkIter   = util::roundToInt(vtkT/dt);    // Número de iteraciones entre volcado del fichero VTK. Redondeando a entero el tiempo entre volcados dividido entre incremento discreto de tiempo.
	
    numOutletSpongeCells = util::roundToInt(outletSpongeZoneWidth/dx);    // Número de nodos en la Sponge Zone. Redondeando a entero la longitud de esta entre el incremento discreto de distancia.
    // Las caras del tunel esta delimitado entre objetos de la clase Box3D, que representan cada una de las caras rectangulares o cuadradas del tunel. Para definir cada una de las caras se sigue la nomenclatura (Posicion X de uno de los vertices, Posicion X del vertice opuesto, Posicion Y de uno de los vertices, Posicion Y del vertice opuesto,Posicion Z de uno de los vertices, Posicion Z del vertice opuesto);
	inlet    = Box3D(0,      0,      0,      ny-1,   0,      nz-1);    // Cara de entrada
    outlet   = Box3D(nx-1,   nx-1,   0,      ny-1,   0,      nz-1);    // Cara de salida
    lateral1 = Box3D(1,      nx-2,   0,      0,      0,      nz-1);    // Lateral 1
    lateral2 = Box3D(1,      nx-2,   ny-1,   ny-1,   0,      nz-1);    // Lateral 2
    lateral3 = Box3D(1,      nx-2,   1,      ny-2,   0,      0);    // Lateral 3
    lateral4 = Box3D(1,      nx-2,   1,      ny-2,   nz-1,   nz-1);    // Lateral 4

    }

    Box3D boundingBox() const    // Función de utilidad, devuelve todo el dominio fluido como un poliedro de 6 caras rectangulares. Se definde con la nomenclatura anterior con un vertice en (0,0,0) y la opuesta en (número de vértices en eje X - 1, número de vértices en eje Y - 1, número de vértices en Z eje - 1)
    {
        return Box3D(0, nx-1, 0, ny-1, 0, nz-1);
    }

    T getInletVelocity(plint iIter)    // Como la velocidad del fluido en la entrada varia con el tiempo se establece esta funcion que nos indica para la iteración iIter, que velocidad corresponde en la entrada.
    {
        static T pi = std::acos((T) -1.0);    // Número pi

        if (iIter >= initialIter) {    // Hasta la iteración initialIter la velocidad se va incrementando progresivamente siguiendo una funcion senoidal. A partir de entonces el valor permanece constante.
            return uLB;
        }

        if (iIter < 0) {    // Si hubier una iteracion negativa, cosa imposible, se reasignaria a un vaor de 0.
            iIter = 0;
        }

        return uLB * std::sin(pi * iIter / (2.0 * initialIter));    // Funcion que incrementa progresivamente la velocidad en la entrada siguiendo una forma senoidal.
    }
};

Param param;    // Declaramos la variable global param de tipo Param.

// Función que establece las condiciones de contorno de las paredes laterales del tunel.
void outerDomainBoundaries(MultiBlockLattice3D<T,DESCRIPTOR> *lattice,    // Bloque Lattice que contiene la dinamica del fluido.
                           MultiScalarField3D<T> *rhoBar,    // Bloque rhobar, utilizado para procesar la densidad
                           MultiTensorField3D<T,3> *j,    // Bloque j, utilizado para procesar la velocidad
                           OnLatticeBoundaryCondition3D<T,DESCRIPTOR> *bc)    // Bloque que contiene métodos necesarios para establecer las condiciones de contorno.
{
    Array<T,3> uBoundary(0.0, 0.0, 0.0);    // Velocidad de las paredes laterales.
	Array<T,3> velSuelo(0.0, 0.0, 0.0);    // Velocidad del fluido en contacto con el suelo.

    if (param.lateralFreeSlip) {    // Condicion de laterales libres.
        pcout << "Laterales sin deslizamiento." << std::endl;    // Imprimir información por pantalla, su unico proposito es informar.

        lattice->periodicity().toggleAll(false);    // Parametro necesario en cada bloque, solo es necesario cambiarlo a True en caso de que se utilicen condiciones periodicas.
        rhoBar->periodicity().toggleAll(false);
        j->periodicity().toggleAll(false);

        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.inlet, boundary::dirichlet);    // En la entrada establecemos una condicion de contorno de tpo Dirichlet, en dicho tipo se establece un valor determinado para la variable.
        setBoundaryVelocity(*lattice, param.inlet, uBoundary);    // En este caso establecemos un valor inicial para la velocidad de (0,0,0), este valor sera actualizado en cada iteración de la simulación hasta llegar a un valor final.

        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral1, boundary::freeslip);    // Los laterales del tunel se establecen como freeslip, esto implica un gradiente cero de la velocidad en la dirección tangencial al lateral y un valor fijo de cero en el resto de las componentes.
        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral2, boundary::freeslip);
        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral3, boundary::freeslip);
        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral4, boundary::freeslip);
        setBoundaryVelocity(*lattice, param.lateral1, uBoundary);    // Establecemos un valor inicial a la velocidad de (0,0,0) en cada uno de los laterales.
        setBoundaryVelocity(*lattice, param.lateral2, uBoundary);
        setBoundaryVelocity(*lattice, param.lateral3, uBoundary);
        setBoundaryVelocity(*lattice, param.lateral4, uBoundary);

        // Las condiciones en la salida son las más complejas, ya que en el tratamiento interno del problema lattice boltzmann implican una mayor cantidad de operaciones.
        Box3D globalDomain(lattice->getBoundingBox());    // Variable que almacena todo el dominio del fluido, se obtiene mediante una llamada a la función getBoundingBox explicada más arriba.
        std::vector<MultiBlock3D*> bcargs;    // Objeto que almacena los bloques lattice, rhobar y j. Necesario para funciones que requieren esta forma más compacta para pasar las variables.
        bcargs.push_back(lattice);    // Introducimos cada una de las variables mediante el metodo push_back.
        bcargs.push_back(rhoBar);
        bcargs.push_back(j);
        T outsideDensity = 1.0;    // Densidad del fluido a la salida
        int bcType = 1;    // Parametro de la función VirtualOutlet que establece el tipo de dominio a usar en la salida.
        integrateProcessingFunctional(new VirtualOutlet<T,DESCRIPTOR>(outsideDensity, globalDomain, bcType),
                param.outlet, bcargs, 2);  // Con integrateProcessingFunctional asociamos una función, en este caso VirtualOutlet, que se ejecuta cada vez que uno de los bloques indicados en el vector bcargs ejecute el metodo executeInternalProcessors. El último parámetro indica la prioridad de ejecución de dicha función para el caso en el que haya más de una.
        setBoundaryVelocity(*lattice, param.outlet, uBoundary);    // Condiciones de la simulación en la salida del tunel. Se empieza con una velocidad de (0,0,0)
    } else {    // Condicion de existencia de suelo.
        pcout << "Condiciones de Suelo." << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.

        lattice->periodicity().toggleAll(false);     // Parametro necesario en cada bloque, solo es necesario cambiarlo a True en caso de que se utilicen condiciones periodicas.
        rhoBar->periodicity().toggleAll(false);
        j->periodicity().toggleAll(false);

        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.inlet, boundary::dirichlet);    // En la entrada establecemos la misma condicion que para el caso anterior.
        setBoundaryVelocity(*lattice, param.inlet, uBoundary);
		bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral1, boundary::dirichlet);    // El lateral con coordenada Y = 0 actuara como suelo, para ello establecemos en el una condición de Dirichlet y fijando la velocidad del fluido a (0,0,0)
        setBoundaryVelocity(*lattice, param.lateral1, velSuelo);

        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral2, boundary::freeslip);    // Las condiciones en el resto de los laterales y parte posterior del tunel son las mismas que para el caso anterior.
        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral3, boundary::freeslip);
        bc->setVelocityConditionOnBlockBoundaries(*lattice, param.lateral4, boundary::freeslip);
        setBoundaryVelocity(*lattice, param.lateral2, uBoundary);
        setBoundaryVelocity(*lattice, param.lateral3, uBoundary);
        setBoundaryVelocity(*lattice, param.lateral4, uBoundary);

        Box3D globalDomain(lattice->getBoundingBox());
        std::vector<MultiBlock3D*> bcargs;
        bcargs.push_back(lattice);
        bcargs.push_back(rhoBar);
        bcargs.push_back(j);
        T outsideDensity = 1.0;
        int bcType = 1;
        integrateProcessingFunctional(new VirtualOutlet<T,DESCRIPTOR>(outsideDensity, globalDomain, bcType),
                param.outlet, bcargs, 2);
        setBoundaryVelocity(*lattice, param.outlet, uBoundary);
    }
}

// Funcion que vuelca el estado del fluido en formato VTK.
void writeVTK(OffLatticeBoundaryCondition3D<T,DESCRIPTOR,Velocity>& bc, plint iT, int j)
{
    VtkImageOutput3D<T> vtkOut(createFileName("volume_iter_"+util::to_string(j)+"_", iT, PADDING));    // Creamos el fichero y le asignamos una codificación que nos ayude a identificar cada fichero en caso de que estempos realizando una misma simulación cambiando los angulos del cuerpo. Un comienzo comun para todos con la cadena "volume_iter_", a la que se añade el número de giros que se le han realizado al sólido y por último la iteración sobre la cual se realiza el volcado. En caso de que el número de la iteración tenga menos dígitos que los definidos en PADDING, se rellena con 0 hasta igualar dichos digitos.
    vtkOut.writeData<float>( *bc.computeVelocityNorm(param.boundingBox()),    // param.boundingBox() devuelve el espacio fluido, sobre el cual se calcula la velocidad normal mediante el método bc.computeVelocityNorm. Para pasarlo de unidades Lattice a las unidades en las que se definio el problema se multiplica por la unidad de distancia Lattice dividido unidad de tiempo Lattice, dicho valor de cambio de escala es el indicado en el tercer parametro del método de volcado de datos del objeto que identifica al fichero creado. Cada campo exportado al formato VTK debe tener un nombre asociado, dicho nombre es el que se indica en el segundo parametro del método, en este caso velocityNorm. En la plantilla indicamos que es de tipo float para indicar que cada valor decimal tiene que usar 32 bits de espacio para almacenar el valor.
                             "velocityNorm", param.dx/param.dt );
    vtkOut.writeData<3,float>(*bc.computeVelocity(param.boundingBox()), "velocity", param.dx/param.dt);    // Mismo caso que el inmediatamente superior, pero en este caso volcamos volcamos el valor completo de toda la velocidad.
    vtkOut.writeData<float>( *bc.computePressure(param.boundingBox()),
                             "pressure", param.densidad*util::sqr(param.dx/param.dt)) );    // Volcado del valor de la presión. El factor de cambio de dimensiones en este caso es densidad*unidad de distancia Lattice al cuadrado dividido unidad de tiempo Lattice al cuadrado.
}

void runProgram(int jj)    // Función que realiza la simulación en si, recibe un parametro ya que puede ejecutarse más de una vez para el mismo cuerpo simplemente cambiando la rotación de este, el parametro indica el número de veces que se ha rotado el cuerpo.
{
    /*
     * Lectura del fichero que contiene el cuerpo sólido.
     */

    pcout << std::endl << "Reading STL data for the obstacle geometry." << std::endl;
    Array<T,3> center(param.cx, param.cy, param.cz);    // Array con la posicion del centro del obstaculo en unidades fisicas
    Array<T,3> centerLB(param.cxLB, param.cyLB, param.czLB);    // Array con la posicion del centro del obstaculo en unidades lattice
    TriangleSet<T> triangleSet(param.geometry_fname, DBL);    // Objeto que define la superficie de la geometria

    // Posicionamiento del obstaculo en las coordenadas idicadas.
    // El centro del obstaculo es calculado por el programa de manera automtica,
	// como la media aritmetica de las posiciones de sus aristas del ortoedro
	// que lo circunscribe, representado por el objeto bCuboid.
    Cuboid<T> bCuboid = triangleSet.getBoundingCuboid();
    Array<T,3> obstacleCenter = (T) 0.5 * (bCuboid.lowerLeftCorner + bCuboid.upperRightCorner);
    triangleSet.translate(-obstacleCenter);
	
    triangleSet.scale(1.0/param.dx); // A partir de ahora en unidades lattice
    triangleSet.rotate(param.phi,param.theta,param.psi);    // Rotamos el obstculo los angulos indicados
    triangleSet.translate(centerLB);    // Trasladamos el centro del cuerpo a las coordenadas indicadas
    triangleSet.writeBinarySTL(outputDir+"obstacle_LB_"+util::to_string(jj)+".stl");    // Guardamos el nuevo obstaculo en un STL nuevo para poder ser visualizado posteriormente.

    plint xDirection = 0;    // Direccion de referencia, el primer elemento de cada vector es la componente X.
    plint borderWidth = 1;      // sobreespesor del borde para el proceso de "Voxelizado"
                                // Obligatorio: margin>=borderWidth.
    plint margin = 1;           // Margen extra asignado a las celdas alrededor del obstaculo, usado en caso de paredes moviles.
    plint blockSize = 0;        // Un valor de cero significa no usar una representacion dispersa de las matrices
	
    DEFscaledMesh<T> defMesh(triangleSet, 0, xDirection, margin, Dot3D(0, 0, 0));    // Objeto de uso temporal para definir el objeto que se define a continuacion
    TriangleBoundary3D<T> boundary(defMesh);    // Objeto que identifica las fronteras del solido

    pcout << "tau = " << 1.0/param.omega << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.
    pcout << "dx = " << param.dx << std::endl;
    pcout << "dt = " << param.dt << std::endl;
	pcout << "uLB = " << param.uLB << std::endl;
    pcout << "Numero de iteraciones: " << maxIter << std::endl;

    /*
     * "Voxelizar" (del ingles Voxelize) el dominio.
     */

    // Voxalizar (Voxelize) el dominio: Decidir que nodos lattice pertenecen al obstculo y cuales al dominio del fluido.
    pcout << std::endl << "Voxelizando el dominio." << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.
    plint extendedEnvelopeWidth = 2;   // Parametro del proceso de "voxelizado" que indca el sobreespesor del cuerpo.
    const int flowType = voxelFlag::outside;    // Flag que indica que se trata de un flujo que circula sobre un cuerpo, la otra opcion es de un flujo que circula dentro de un cuerpo.
    VoxelizedDomain3D<T> voxelizedDomain (
            boundary, flowType, param.boundingBox(), borderWidth, extendedEnvelopeWidth, blockSize );    // Objeto que almacena el dominio de nodos lattice "voxelizados"
    pcout << getMultiBlockInfo(voxelizedDomain.getVoxelMatrix()) << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.

    /*
     * Generacion de los bloques lattice, rhoBar (densidad) y j (momento)
     */

    pcout << "Generating the lattice, the rhoBar and j fields." << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.
    MultiBlockLattice3D<T,DESCRIPTOR> *lattice = new MultiBlockLattice3D<T,DESCRIPTOR>(voxelizedDomain.getVoxelMatrix());    // Creacion del bloque lattice a partir del dominio "voxeliado". Este objeto es el más importante de todos, ya que contiene todos los datos necesarios de la simulación, y a traves de sus metodos se realizan las diversas iteraciones del metodo LB.
    //    Asignación de la dimanica deseada al bloque lattice, se compara el valor almacenado en la variable modelo con las distintas dinamicas aceptadas por el programa y se asigna dicha dinamica con los parametros establecidos.
    if (param.modelo == "Smagorinsky") {    // Dinamica BGK con un modelo de turbulencia de tipo "Large Eddy Simulation"
        defineDynamics(*lattice, lattice->getBoundingBox(),    // defineDynamics es la funcion que asocia al bloque lattice una dinamica, dicha dinamica se pasa como un objeto en la tercera posicion de la función, la primera es el bloque lattice en si y la segunda es el dominio fluido sobre el cual se define.
                new SmagorinskyBGKdynamics<T,DESCRIPTOR>(param.omega, param.cSmago));
        pcout << "Using Smagorinsky BGK dynamics." << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.
    } else if (param.modelo == "BGK") {    // Dinamica BGK simple
        defineDynamics(*lattice, lattice->getBoundingBox(),
                new BGKdynamics<T,DESCRIPTOR>(param.omega));
        pcout << "Using BGK dynamics." << std::endl;
    } else if (param.modelo == "Entropic") {    // Usando un modelo entropico.
        defineDynamics(*lattice, lattice->getBoundingBox(),
                new EntropicDynamics<T,DESCRIPTOR>(param.omega));
        pcout << "Using Entropic dynamics." << std::endl;
    } else if (param.modelo == "Regularized"){    // Usando un modelo BGK Regularizado.
        defineDynamics(*lattice, lattice->getBoundingBox(),
                new RegularizedBGKdynamics<T,DESCRIPTOR>(param.omega));
        pcout << "Using Regularized BGK dynamics." << std::endl;
    }
    bool velIsJ = false;    // flag utilizada en el objeto offLatticeModel para saber si el bloque de velocidades que se utiliza es j (densidad*velocidad)
    defineDynamics(*lattice, voxelizedDomain.getVoxelMatrix(), lattice->getBoundingBox(),
            new NoDynamics<T,DESCRIPTOR>(), voxelFlag::inside);    // Dinamica nula para los nodos en el interior del sólido.
    lattice->toggleInternalStatistics(false);    // toggleInternalStatistics es un metodo utilizado para obtener estadisticas internas del bloque en cada iteración, al ponerlo com false desactivamos esta funcionalidad.

    // Los bloques rhoBar y j son usados ambos en the collision y en la implementación de las condiciones de salida del tunel.
    MultiScalarField3D<T> *rhoBar = generateMultiScalarField<T>((MultiBlock3D&) *lattice ).release();    // Generación del bloque rhobar, a traves del bloque lattice generamos un bloque generateMultiScalarField que posteriormente genera un bloque MultiScalarField a traves del método release(). Se utiliza este metodo, con el bloque lattice como bloque madre, ya que nos interesa que sean bloques con identico número de nodos, aunque en los nodos de rhoBar se almacenara el valor de la densidad en cada nodo - 1.
    rhoBar->toggleInternalStatistics(false);    // toggleInternalStatistics es un metodo utilizado para obtener estadisticas internas del bloque en cada iteración, al ponerlo com false desactivamos esta funcionalidad.

    MultiTensorField3D<T,3> *j = generateMultiTensorField<T,3>((MultiBlock3D&) *lattice ).release();    // Generación del bloque j, a traves del bloque lattice generamos un bloque generateMultiTensorField que posteriormente genera un bloque MultiTensorField3D a traves del método release(). Se utiliza este metodo, con el bloque lattice como bloque madre, ya que nos interesa que sean bloques con identico número de nodos, aunque en los nodos de j se almacenara un vector con los valores de la velocidad en cada nodo multiplicado por la densidad en dicho nodo.
    j->toggleInternalStatistics(false);    // toggleInternalStatistics es un metodo utilizado para obtener estadisticas internas del bloque en cada iteración, al ponerlo com false desactivamos esta funcionalidad.

    std::vector<MultiBlock3D*> lattice_rho_bar_j_arg;    // Objeto que almacena los bloques lattice, rhobar y j. Necesario para funciones que requieren esta forma más compacta para pasar las variables.
    lattice_rho_bar_j_arg.push_back(lattice);    // Con el método push_back vamos introduciendo cada uno de los bloques.
    lattice_rho_bar_j_arg.push_back(rhoBar);
    lattice_rho_bar_j_arg.push_back(j);
    integrateProcessingFunctional(
            new ExternalRhoJcollideAndStream3D<T,DESCRIPTOR>(),
            lattice->getBoundingBox(), lattice_rho_bar_j_arg, 0);    // Con integrateProcessingFunctional asociamos una función, en este caso ExternalRhoJcollideAndStream3D, que se ejecuta cada vez que uno de los bloques indicados en el vector bcargs ejecute el metodo executeInternalProcessors. El último parámetro indica la prioridad de ejecución de dicha función para el caso en el que haya más de una.
    integrateProcessingFunctional(
            new BoxRhoBarJfunctional3D<T,DESCRIPTOR>(),
            lattice->getBoundingBox(), lattice_rho_bar_j_arg, 3);     // Con integrateProcessingFunctional asociamos una función, en este caso BoxRhoBarJfunctional3D, que se ejecuta cada vez que uno de los bloques indicados en el vector bcargs ejecute el metodo executeInternalProcessors. El último parámetro indica la prioridad de ejecución de dicha función para el caso en el que haya más de una.
			// Con BoxRhoBarJfunctional3D se calculan los bloques rhoBar and j. Se calculan en el nivel 3, primero se ejecutan las funciones implementadas en niveles inferiores,
            // ya que las condiciones de contorno son calculadas a nivel 1 y 2.

    /*
     * Generación de las condiciones de contorno off-lattice (las condiciones alrededor del obstaculo), y las condiciones outer-domain (condiciones alrededor de todo el domino fluido)
     */

    pcout << "Generating boundary conditions." << std::endl;    // Imprimir información por pantalla, su unico proposito es informar.

    OffLatticeBoundaryCondition3D<T,DESCRIPTOR,Velocity> *boundaryCondition;    // Bloque que almacena información de las condiciones de contorno del obstculo, tambien almacena información del estado del flujo en los nodos pegados a este.

    BoundaryProfiles3D<T,Velocity> profiles;    // Objeto que almacena las especificaciones que tienen que cumplir los nodos que esten en contacto con el cuerpo para cumplir con las condiciones de contorno que se impongan a este.
    OffLatticeModel3D<T,Velocity>* offLatticeModel=0;    // Bloque auxiliar para acabar constuyendo boundaryCondition
    if (param.freeSlipWall) {    // Si se desea que el cuerpo tenga la condicion de no deslizamiento:
        profiles.setWallProfile(new FreeSlipProfile3D<T>);    // Le asociamos mediante el metodo setWallProfile dicha condicion condicion mediante el objeto FreeSlipProfile3D.
    }
    else {    // En cso contrario:
        profiles.setWallProfile(new NoSlipProfile3D<T>);    // Establecemos una condicion de no deslizamiento
    }
    offLatticeModel =
         new GuoOffLatticeModel3D<T,DESCRIPTOR> (
            new TriangleFlowShape3D<T,Array<T,3> >(voxelizedDomain.getBoundary(), profiles),
            flowType );    /* Para darle un valor a offLatticeModel creamos:
			1º -> Creamos un objeto de tipo TriangleFlowShape3D, donde se especifica el dominio voxelizado, nos interesan los nodos cercanos al bloque interno, donde deja de ser dominio fluido.
			2º -> Pasamos el objeto profiles, donde hemos especificado que condiciones queremos que tengan dichos nodos.
			
			Posteriormente, pasamos este objeto creado y el tipo de flujo, en este caso es flujo esterior a un objeto, al constructor de la funcion GuoOffLatticeModel3D, que nos devuelve el objeto offLatticeModel.
			*/
    offLatticeModel->setVelIsJ(velIsJ);    // Mediante la flag velIsJ le indicamos al bloque offLatticeModel creado que trabaje con valores de velocidad, no de velocidad*densidad.
    boundaryCondition = new OffLatticeBoundaryCondition3D<T,DESCRIPTOR,Velocity>(
            offLatticeModel, voxelizedDomain, *lattice);    // A partir del bloque auxilizar offLatticeModel,que contiene la información relativa al tipo de condicion de contorno a usar en el cuerpo, el dominio voxelizado y el bloque lattice creamos el objeto boundaryCondition, a partir de ahora utilizamos este objeto para cualquier calculo requerido en el que este involucrado el cuerpo de estudio.

    boundaryCondition->insert();    // Metodo para inicizalizar las condiciones del objeto.

    // Condiciones de contorno del exterior del dominio fluido.
    OnLatticeBoundaryCondition3D<T,DESCRIPTOR>* outerBoundaryCondition
        = createLocalBoundaryCondition3D<T,DESCRIPTOR>();    // Objeto creado que almacena la informacion relativa a las condiciones de contorno exteriores.
    outerDomainBoundaries(lattice, rhoBar, j, outerBoundaryCondition);    // funcion que asocia las condiciones creadas con los distintos bloques. Al contrario que con las condiciones del cuerpo, donde el objeto qe las carcterza impone las condiciones sobre el dominio fluido, bloque lattice, en el caso de las condiciones exteriores este objeto creado no se utiliza como interfaz para establecer las condiciones, en su lugar mediante la funcion setBoundaryVelocity se impondran las condiciones directamente sobre el bloque lattice, la utilidad de este objeto es solo para so interno del framework.

    /*
     * Implementación de la sponge zone.
     */

    if (param.numOutletSpongeCells > 0) {    // Solo se implementa si el número de nodos que la implementen es mayor que 0.
        T bulkValue;    // Parametro utilizado en la dinamica de la sponge zone, coincide con omega o con la viscosidad de Smagorinsky, segun como se defina dicha dinamica.
        Array<plint,6> numSpongeCells;    // Vector que indica en cada lateral del tunel el número de nodos a implementar con Sponge Zone. Más adelante se especifica como se utiliza en cada lateral.

        if (param.outletSpongeZoneType == 0) {    // Si se desea utilizar una dinamica viscosa en la Sponge Zone
            pcout << "Generating an outlet viscosity sponge zone." << std::endl;    // Imprimir información por pantalla, su unico proposito es informar.
            bulkValue = param.omega;    // Se utliza una dinamica similar al caso BGK, tiene una constante igual al parametro omega.
        } else if (param.outletSpongeZoneType == 1) {    // Si se desea utilizar una dinamica de Smagorinsky en la Sponge Zone
            pcout << "Generating an outlet Smagorinsky sponge zone." << std::endl;    // Imprimir información por pantalla, su unico proposito es informar.
            bulkValue = param.cSmago;    // Se utliza una dinamica similar al caso Smagorinsky, tiene una constante igual a la constante de Smagorinsky.
        } else {    // En caso de que no se haya especificado ninguna de las dos, es un caso de error.
            pcout << "Error: unknown type of sponge zone." << std::endl;    // Se muestra un mensaje de error par informar de que se ha especificado mal.
            exit(-1);     // Se sale del programa.
        }

        // Número de nodos lattice sponge a lo largo de todos las fronteras.
        //     El indice 0 indica el número de nodos a tomar a partir de x = 0
        //     El indice 1 indica el número de nodos a tomar a partir de x = nx-1
        //     El indice 2 indica el número de nodos a tomar a partir de y = 0
        //     ...
		//
		//    En este programa solo se permite utilizar una zona Sponge en la parte final del tunel, si se deseasen utilziar en los demas entornos habría que realizar una modificación en el indice del vector numSpongeCells correspondiente, indicando el número de nodos en los que implementar la Sponge Zone.
        numSpongeCells[0] = 0;
        numSpongeCells[1] = param.numOutletSpongeCells;    // Solo se permite establecer nodos en la parte trasera del tunel.
        numSpongeCells[2] = 0;
        numSpongeCells[3] = 0;
        numSpongeCells[4] = 0;
        numSpongeCells[5] = 0;
		
		// La dinamica en la Sponge Zone se implementa mediante applyProcessingFunctional, funciona de manera similar a integrateProcessingFunctional, pero mientras que con integrateProcessingFunctional se ejecutaba la funcion cada vez que se llamaba al metodo executeInternalProcessors(), con applyProcessingFunctional solo se aplica la funcion en el momento de su asignacion

        std::vector<MultiBlock3D*> args;    // Parametros a pasar a la funcion applyProcessingFunctional
        args.push_back(lattice);    // Solo es necesario el bloque lattice.

        if (param.outletSpongeZoneType == 0) {    // Si se quiere implementar una dinamica viscosa.
		    // applyProcessingFunctional recibe como parametros:
			// 1º -> La dinamica deseada en forma de objeto, en este caso ViscositySpongeZone para indicar que queremos una dinamica viscosa. A su ves este recibe como parametros: el tamaño del dominio fluido, el valor de su constante dinamica y las celdas en las que implemntar la sponge zone, esta ultima información va codificada segun el vector explicado anteriormente.
			// 2º -> Dominio fluido sobre los que aplicar la función.
			// 3º -> Bloques a los que implementar la funcion, pasados en forma de vector.
            applyProcessingFunctional(new ViscositySpongeZone<T,DESCRIPTOR>(
                        param.nx, param.ny, param.nz, bulkValue, numSpongeCells),
                    lattice->getBoundingBox(), args);
        } else {    // Si se quiere implementar una dinamica de Smagorinsky.
		    // Mismo caso que el anteror, solo qe esta vez se aplica una dinamica de tipo SmagorinskySpongeZone.
            applyProcessingFunctional(new SmagorinskySpongeZone<T,DESCRIPTOR>(
                        param.nx, param.ny, param.nz, bulkValue, param.targetSpongeCSmago, numSpongeCells),
                    lattice->getBoundingBox(), args);
        }
    }

    /*
     * Se establecen las condiciones iniciales
     */

    // Condiciones Iniciales: Presión (y densidad) constante y velocidad nula en todo el dominio fluido.
    Array<T,3> uBoundary(param.getInletVelocity(0), (T)0.0, (T)0.0);    // Velocidad Inicial del flujo.
	// La funcion initializeAtEquilibrium impone en el bloque lattice unas condiciones iniciales de equilirbio como se especifican en los parametros.
	// Parametros:
	// 1º -> El bloque lattice.
    // 2º -> El dominio del fluido.
	// 3º -> La densidad del fluido.
	// 4º -> La velocidad a imponer en el dominio del fluido.
    initializeAtEquilibrium(*lattice, lattice->getBoundingBox(), (T)1.0, uBoundary);    // Es MUY importante que la densidad del fluido sea 1.0 o cercano a este valor, ya que por motivos de estabilidad del método es necesario que dicho valor permanezca cercano a 1.0. Para poder fijarla como 1.0 el programa ha relaizado todo el proceso de adimensionalización respecto a la densidad transparente al usuario y poder fijar aqui una densidad adimensionalizada que garantiza la mayor estabilidad posible al método.
    applyProcessingFunctional(
            new BoxRhoBarJfunctional3D<T,DESCRIPTOR>(),
            lattice->getBoundingBox(), lattice_rho_bar_j_arg); // Se calcula el valor de los bloques rhoBar and j con las condiciones iniciales.

    /*
     * Particulas Virtuales (Lineas de corriente).
     */

    // Esta parte del codigo es la encargada de preparar los bloques que trabajan con las paticulas virtuales.
    // Las particulas virtuales se utilizan únicamente para el calculo de lineas de corriente.

    // Definición del campo de particle virtuales.
    MultiParticleField3D<ParticleFieldT>* particles = 0;    // Campo de particulas virtuales. Se inicializa nulo, si se ha especificado usar particular virtuales se creara un dominio util.

    if (param.useParticles) {    // Si se ha especificado usar particular virtuales.
        particles = new MultiParticleField3D<ParticleFieldT> (    // Campo de particulas virtuales, para vincularlo con el dominio del bloque lattice utilizamos su metodo getMultiBlockManagement
            lattice->getMultiBlockManagement(),
            defaultMultiBlockPolicy3D().getCombinedStatistics() );

        std::vector<MultiBlock3D*> particleArg;    // Vector qe almacenara el vector de particulas para integrarle una función mediante integrateProcessingFunctional.
        particleArg.push_back(particles);    // Se añade el bloque de particulas virtuales al vector.

        std::vector<MultiBlock3D*> particleFluidArg;    // Segundo vector que almacena bloques para asociarles funciones. Este vector almacena tanto el campo de particulas virtuales como al bloque lattice.
        particleFluidArg.push_back(particles);
        particleFluidArg.push_back(lattice);

        // Funcion que posiciona las particulas en su nueva posición en cada iteracion
        integrateProcessingFunctional (
                new AdvanceParticlesEveryWhereFunctional3D<T,DESCRIPTOR>(param.cutOffSpeedSqr),
                lattice->getBoundingBox(), particleArg, 0);
        // Función que asigna a las particulas su velocidad, de acuerdo al estado del bloque lattice del fluido.
        integrateProcessingFunctional (
                new FluidToParticleCoupling3D<T,DESCRIPTOR>((T) param.particleTimeFactor),
                lattice->getBoundingBox(), particleFluidArg, 1 );

        // Dominio sobre el cual se inyectaran nuevas particlas virtuales de forma aleatoria. Este dominio es un paralelogramo en el plano perpendicular a X=0, centrado en los ejes Y y Z del dominio y de longitud en cada uno de estos ejes la mitad del tamaño del dominio fluido en ellos.
        Box3D injectionDomain(0, 0, centerLB[1]-0.25*param.ny, centerLB[1]+0.25*param.ny,
                centerLB[2]-0.25*param.nz, centerLB[2]+0.25*param.nz);

        // Campo de particulas sin masa, utilizado para inyectar particulas
        Particle3D<T,DESCRIPTOR>* particleTemplate=0;
        particleTemplate = new PointParticle3D<T,DESCRIPTOR>(0, Array<T,3>(0.,0.,0.), Array<T,3>(0.,0.,0.));

        // Vector con los parametros en los que inyectar particulas virtuales nuevas, logicamente es el campo de particulas virtuales.
        std::vector<MultiBlock3D*> particleInjectionArg;
        particleInjectionArg.push_back(particles);

        integrateProcessingFunctional (    // Asocimos al bloque de particulas virtuales la funcion que inyecta nuevas particulas virtuales en el vector definido justo anteriormente, del bloque particleTemplate de particulas sin masa, con la probabilidad indicada en particleProbabilityPerCell, en el dominio injectionDomain,
                new InjectRandomParticlesFunctional3D<T,DESCRIPTOR>(particleTemplate, param.particleProbabilityPerCell),
                injectionDomain, particleInjectionArg, 0 );

        // La salida del tunel se define como un bloque, posteriormente se asociara a este bloque una funcion que absorbera las particulas virtuales en esta zona.
        Box3D absorbtionDomain(param.outlet);

        // Asociamos al bloque de particulas virtuales, que se encuentra dentro del vector particleArg, una funcion que absorbera las particulas virtuales que se encuentren en la salida del tunel.
        integrateProcessingFunctional (
                new AbsorbParticlesFunctional3D<T,DESCRIPTOR>, absorbtionDomain, particleArg, 0 );

        particles->executeInternalProcessors();    // Ejecutamos las funciones asociadas con integrateProcessingFunctional para inicializar el bloque de particulas virtuales.
    }

    /*
     * Comienzo de la simulación.
     */

    plb_ofstream ForcesFile((outputDir + "ForcesFile_" + util::to_string(jj) + ".dat").c_str());    // Creción de fichero qe contiene las fuerzas sobre el sólido, se trata como un fichero de texto normal sobre el cual se iran imprimiendo los datos siguiendo un formato CSV. El nombre del fichero sigue una codificación especial para identificar cada uno de ellos cuando se realizan varias simulaciones siguiendo una rotación del cuerpo de estudio. Todos comienzan por la cadena ForcesFile_ siguiendo el número de giros que acumula en sólido en la simulación, y por ultimo se añade una extenson .dat

    pcout << std::endl;    // Imprimir salto de linea extra por pantalla, su unico proposito es organizar mejor la informción mostrada.
    pcout << "Starting simulation." << std::endl;    // Imprimir información por pantalla, su unico proposito es informar de que empieza a simulación.
    for (plint i = 0; i < param.maxIter; ++i) {    // Bucle de la simulación. Cada iteración de este bucle es una iteración del método Lattice-Boltzmann.
        if (i <= param.initialIter) {    // Durante las primeras iteraciones se produce una aceleración del flujo en la entrada.
            Array<T,3> uBoundary(param.getInletVelocity(i), 0.0, 0.0);    // La funcion getInletVelocity se encara de dar obtener un valor que incrementa gradualmente hasta alcanzar el valor final. En las iteraciones iniciales la velocidad en el eje X va acelerandose siguendo esta progresión.
            setBoundaryVelocity(*lattice, param.inlet, uBoundary);    // Funcion que asigna al bloque lattice (primer parametro), en su cara de entrada (segundo parametro), la velocidad indicada en el tercer parametro.
        }

        if (i % param.statIter == 0) {    // Cada número de iteraciones indicadas en la variable statIter volcamos los datos por pantalla y al fichero que almacena las fuerzas sobre el cuerpo.
             pcout << "At iteration " << i << ", t = " << i*param.dt << std::endl;     // Se imprime por pantalla el tiempo de simulación que se lleva realizado.
             Array<T,3> force(boundaryCondition->getForceOnObject());    // Mediante el método getForceOnObject() del objeto boundaryCondition, que contiene la informacion referente a las condiciones en el contorno del sólido, se obtiene la fuerza resultante sobre el objeto.
             T factor = (util::sqr(util::sqr(param.dx)) / util::sqr(param.dt))*param.densidad;    // Factor utilizado para pasar las unidades de la fuerza del sistema adimensonal usado en el método Lattice Botzmann, al sistema de dimensiones que ha introducido el usuario, mediante la multiplicación de los valores de la fuerza adimensional por dicho factor.
             pcout << "Force on object over fluid density: F[x] = " << force[0]*factor << ", F[y] = "    // Escribimos por pantalla el resultado de las fuerzas sobre el cuerpo. Su unico proposito es proporcionar información durante la simulación.
                   << force[1]*factor << ", F[z] = " << force[2]*factor << std::endl;
             T avEnergy = boundaryCondition->computeAverageEnergy() * util::sqr(param.dx) / util::sqr(param.dt);    // Creamos una variable que almacena el promedio de la energia cinetica del fluido que rodea al cuerpo entre la densidad del fluido. Su unico proposito es imprimirse por pantalla como información adicional.
             ForcesFile << i*param.dt << ";" << force[0]*factor << ";" << force[1]*factor << ";" << force[2]*factor << std::endl;    // Volcado de las fueras en el fichero ForcesFile. Se sigue un formato de CSV usando como separador ";". Se almacenan por orden los valores del vector de fuerza, primero el valor en el eje X, almacenado en el elemento [0] del array force, despues el valor en la dirección del eje Y, almacenado en el elemento [1] y por último el valor en el eje Z, almacenado en [2]. Para escalarlo con el sistema de unidades introducido por el usuario, lo multiplicamos por el factor de escla almcenado en la variable factor.
             pcout << "Average kinetic energy over fluid density: E = " << avEnergy << std::endl;    // Imprimir datos por pantalla, su unico proposito es informar.
             pcout << std::endl;    // Imprimir salto de linea extra por pantalla, su unico proposito es organizar mejor la informción mostrada.
        }

        if (param.vtkFile) {    // Si se desea volcar el estado de la simulación en VTK.
			if (i % param.vtkIter == 0) {    // Cada número de iteraciones indicadas en vtkIter realizamos el volcado en formato VTK.
				pcout << "Writing VTK at time t = " << i*param.dt << endl;    // Imprimir datos por pantalla, su unico proposito es informar.
				writeVTK(*boundaryCondition, i, jj);    // Llamamos a la funcion que se encarga de volcar los datos.
				if (param.useParticles) {    // Si se desea utilizar particulas virtuales con proposito de visualizacion se escriben en un fichero con extension vtk
					writeParticleVtk<T,DESCRIPTOR> (    // Funcion que vuelca el estado de las particulas, el primer parametro es el bloque que las almacena, el segundo el fichero sobre el cual se vuelcan y el tercero el número máximo de particulas a escribir.
							*particles, createFileName(outputDir+"particles_iter_"+util::to_string(jj)+ "_", i, PADDING) + ".vtk",    // La codificación en el nombre del fichero que utilizamos es la misma que la utilizada en los ficheros vti, explicada en la función writeVTK.
							param.maxNumParticlesToWrite );
				}
			}
		}

        lattice->executeInternalProcessors();    // Ejecución del metodo executeInternalProcessors del bloque lattice, con esto ejecutamos todas las funciones que le hemos asignado al bloque mediante la funcion integrateProcessingFunctional.
        lattice->incrementTime();    // Incrementamos el tiempo de la simulacion en un valor dt.
        if (param.useParticles && i % param.particleTimeFactor == 0) {    // Cada número de iteraciones indicadas en la variable particleTimeFactor calculamos la nueva distribucion de  particulas del bloque particles.
            particles->executeInternalProcessors();    // Ejecución del metodo executeInternalProcessors ddel bloque lattice, con esto ejecutamos todas las funciones que le hemos asignado al bloque mediante la funcion integrateProcessingFunctional.
        }
    }

    ForcesFile.close();    // Cerramos el fichero en el que hemos volcado el valor de las fuerzas.
    delete outerBoundaryCondition;    // Borramos de forma segura el bloque outerBoundaryCondition de la memoria.
    delete boundaryCondition;    // Borramos de forma segura el bloque boundaryCondition de la memoria.
    if (param.useParticles) {
        delete particles;    // Borramos de forma segura el bloque particles de la memoria. Lo introducimos dentro de un if para verificar que se ha creado con anterioridad.
    }
    delete j;    // Borramos de forma segura el bloque j de la memoria.
    delete rhoBar;    // Borramos de forma segura el bloque rhoBar de la memoria.
    delete lattice;    // Borramos de forma segura el bloque lattice de la memoria.
}

int main(int argc, char* argv[])
{
    plbInit(&argc, &argv);    // Funcion que se encarga de pasar los parametros a todos los procesos MPI que ejecutan el programa. Tambien 
    global::directories().setOutputDir(outputDir);    // Se establece el lugar donde se volcaran las salidas.
    pid_t pid;    // pid del proceso una vez se llame a fork.
    int i;    // Variable que almacenara la respuesta del proceso hijo.

    // Se usan bloques try-catch por si ocurren errores. En caso de que ocurran son capturados por el bloque catch
    // y termina el programa de manera correcta mostrando el mensaje de error adecuado.

    // 1. Leer los parametros de la linea de comandos: el fichero XML y opcionalmente la contraseña del correo
    string xmlFileName;    // Nombre del fichero XML que almacena los datos de configuración.
    string password;   // Almacena la contraseña del correo, no se pasa por el XML por motivos de seguridad
    try {
        global::argv(1).read(xmlFileName);    // Primera opcion de la linea de comandos el nombre del fichero XML
        if (global::argc()==3) {    // Si se han pasado 2 opciones al comando
            global::argv(2).read(password);    // Leer la contraseña del correo
        }
    }
    catch (PlbIOException& exception) {
        pcout << "Wrong parameters; the syntax is: "
              << (std::string)global::argv(0) << " input-file.xml [email password]" << std::endl;    // Se indica la manera correcta de utilización
        return -1;
    }

    // 2. Leer el fichero XML
    try {
        param = Param(xmlFileName);    // Ejecucion de la funcion Param con el nombre del fichero XML como parametro.
    }
    catch (PlbIOException& exception) {    
        pcout << exception.what() << std::endl;    
        return -1;
    }
	
	// 3. Ejecucion de la simulación

    // 3.1. Se establecen los giros iniciales del sólido en cada iteracion
	for (int j = 0; j < param.iteracionesPrograma; ++j) {

		if (j != 0) {
			param.psi = param.psi + param.deltapsi;
                        param.theta = param.theta + param.deltatheta;
                        param.phi = param.phi + param.deltaphi;
		}

    // 3.2. Se ejecuta el programa principal
    	try {
        	runProgram(j); // Se pasa como parametro la variable del bucle for para diferenciar los ficheros de volcado de datos en cada iteración.
    	}
    	catch (PlbIOException& exception) {
        	pcout << exception.what() << std::endl;
        	return -1;
    	}
	} 

    // 4. Llamarda al sistema de avisos

        global::mpi().barrier();    // Espera a que todos los procesos lleguen a este punto

        if (global::mpi().getRank() == 0) {     // Si el proceso tiene rango 0
            if ((pid = fork()) == 0) {    // Se crea un nuevo subproceso con fork, en caso de que sea el hijo
			//TODO incluir el caso del error
                if (global::argc()==3) {       // Si se ha llamado con 3 parametros significa que se le ha pasado la contraseña del email
                    execl( "/usr/bin/python", "python", "bot.py", password.c_str(), (char*)0 ); //El subproceso hijo se transforma en un nuevo proceso que ejecuta el sistema de avisos
                } else if (global::argc()==2) {      // Si se ha ejecutado con 2 parametros significa que no se desea utilizar el sistema de avisos por email.
                    execl( "/usr/bin/python", "python", "bot.py", (char*)0 );  //El subproceso hijo se transforma en un nuevo proceso que ejecuta el sistema de avisos
                }
            }
            else {
                pid = wait(&i);    // El proceso padre espera a que el hijo acabe su ejecución.
            }
        }
        global::mpi().barrier();     // Espera a que todos los procesos lleguen a este punto, se espera a que el proceso encargado de llamar al sistema de avisos llegue para finalizarse todos al mismo tiempo.
}

