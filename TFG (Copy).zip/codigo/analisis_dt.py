#!/usr/bin/env python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from lxml import etree
from io import StringIO
import glob
import os
from scipy import interpolate
from math import *
'''Unico valor que no se lee del archivo XML'''
D=np.float64(0.2) # Diámetro de la esfera.
'''Nombres ficheros utiles'''
nombreArchivoFueras = 'ForcesFile_0.csv' # Fichero que contiene las fuerzas
nombreArchivoConfiguracion = 'externalFlowAroundObstacle.xml' # Fichero de configuración
nombreArchivoFuerzasReferencia = 'Referencia.csv' # Fichero con los coeficientes de arrastre de referencia
'''Variables usadas'''
area=np.float64(np.pi*(D/2)*(D/2)) #Área frontal de la esfera
numerosReynolds=[] # Número de Reynolds de cada simulación, se van almacenando en forma de tupla
coeficienteArrastre=[] # Coeficientes de arrastre de cada simulación, se van almacenando en forma de tupla
resolutiones=[] # Conjunto de valores dt, se van almacenando en forma de tupla
for carpeta in glob.glob('tmp*'): # Para cada carpeta que empiece por tmp-. Cada uno de estos ficheros contiene el resultado de una de las simulaciones realizadas.
	'''Ir a la carpeta, leer los ficheros necesarios y volver'''
	os.chdir(carpeta) # Ir a esa carpeta
	f = open(nombreArchivoConfiguracion) # Abrir el fichero de configuración
	xml = f.read() # Leer el fichero de configuración y se guarda su contenido en la variable xml
	f.close() # Cerrar el fichero de configuración.
	tree = etree.parse(StringIO(xml)) # Parsear el contenido del archivo de configuración con el parser XML
	velocidadString = tree.xpath('//inletVelocity')[0].text # Buscar la entrada que indica la velocidad del fluido
	velocidad = np.float64(velocidadString) # Se para la velocidad del fluido a una variable numérica
	visc_dString = tree.xpath('//nu')[0].text # Buscar la entrada que indica la viscosidad del fluido
	visc_d=np.float64(visc_dString) # Se para la viscosidad del fluido a una variable numérica
	rho_dString = tree.xpath('//ro')[0].text # Buscar la entrada que indica la densidad del fluido
	rho_d=np.float64(rho_dString) # Se para la viscosidad del densidad a una variable numérica
	resolucionString=tree.xpath('//dt')[0].text # Se busca la entrada del parámetro dt
	resolucion=np.float64(resolucionString) # Se pasa el parámetro dt a una variable numérica
	file = pd.read_csv(nombreArchivoFueras,sep=';',names=['time','fx','fy','fz']) # Procesado del fichero que tiene las fuerzas. Es un fichero CSV con cuatro columnas, instante de tiempo y fuerza en cada uno de los tres ejes, separados por el caracter ';'.
	os.chdir('..') # Salir de la carpeta
	'''Calculo de la fuerza final'''
	fxMean=(file[file.time > 5.0]['fx'].mean()) # Para calcular la fuerza resultante, se calcula la média a partir de un valor lo suficientemente alto como para que se haya estabilicado el flujo.
	'''Agregar los valores que se quieren almacenar en las listas'''
	coeficienteArrastre.append(2*fxMean/(rho_d*(velocidad**2)*area)) # Se calcula el coeficiente de arrastre para la simulación dada y se almacena en la tupla.
	numerosReynolds.append(velocidad*D/visc_d) # Se calcula el número de Reynolds para la simulación dada y se almacena en la tupla.
	resolutiones.append(resolucion) # Se van almacenando los valores de dt probados en una tupla.
resolutiones=np.array(resolutiones) # Se cambia el conjunto de valores de dt probados a un array.
'''Crear los fucheros Cd_dt.dat y Force_vs_dt.dat'''
coeficienteArrastreResolucion=pd.Series(coeficienteArrastre, index=resolutiones)  # Se crea una serie con el indice el valor de dt y el coeficiente de arrastre asociado
coeficienteArrastreResolucion.to_csv('Cd_dt.csv',sep=';') # Se vuelca la serie anterior a un fichero csv, utilizando como separador en parámetro ';'.
'''Calculo del error'''
csvReferenciaFuerza=pd.read_csv(nombreArchivoFuerzasReferencia,sep=';',names=['Re','Cd']) # Se toman los valores de Cd frente a Re de referencia extraidos.
interpolador = interpolate.interp1d(csvReferenciaFuerza['Re'],csvReferenciaFuerza['Cd'], kind='quadratic', bounds_error=True) # Se crea un interpolador cuadrático que interpola entre los valores cargados anteriormente.
error = (interpolador(numerosReynolds)-coeficienteArrastre)/interpolador(numerosReynolds) # Se calcula el error relativo. Para ello se resta el valor teórico, obtenido interpolando el número de Reynolds de la simulación con el interpolador creado anteriormente, con el coeficiente de arrastre obtenido, y dividiendo por el valor teórico.
'''Dibujar Error / dt'''
plt.figure('Error frente a dt') # Nombre de la figura, solo tiene interes a nivel interno del programa
plt.scatter(resolutiones*1000,error*100) # Se indican las coordenadas de los puntos en el eje X y en el eje Y
plt.title(u'Error frente a  $\delta_t$') # Titulo de la figura
plt.ylim(min(error*100)*1.1,max(error*100)*0.9) # Se establecen los limites de los valores a mostrar en el eje Y
plt.xlim(min(resolutiones*1000)*0.9,max(resolutiones*1000)*1.1) # Se establecen los limites de los valores a mostrar en el eje X
plt.grid(True) # Se mostrara una malla de fondo
plt.minorticks_on() # Se muestran más marcas en los ejes
plt.xlabel(u'$\delta_t$ (·1000)') # Nombre del eje X
plt.ylabel(u'Error (%)') # Nombre del eje Y
plt.savefig('Error_vs_dt.png', dpi=400, bbox_inches='tight') # Se guarda la gráfica en un fichero png
plt.close # Se cierra la figura
'''Crear fichero Error / dt'''
df=pd.DataFrame(data=error, index=resolutiones, columns=['error (t/1)']) # Se crea un dataframe que contiene el error obtenido para cada dt.
df.to_csv('Error_vs_dt.csv', sep=';') # Se vuelca el dataframe anterior a un fichero csv, utilizando como separador en parámetro ';'.